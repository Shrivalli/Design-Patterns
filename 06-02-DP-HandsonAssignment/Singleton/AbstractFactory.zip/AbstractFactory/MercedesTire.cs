﻿namespace AbstractFactory
{
    class MercedesTire : Tire
    {

    }
}
