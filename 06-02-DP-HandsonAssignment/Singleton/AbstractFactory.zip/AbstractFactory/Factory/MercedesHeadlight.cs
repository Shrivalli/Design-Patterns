﻿namespace AbstractFactory
{
    class MercedesHeadlight : Headlight
    {

    }
}
