﻿namespace AbstractFactory
{
    abstract class Tire
    {
        
    }
}
