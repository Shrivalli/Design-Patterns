﻿namespace AbstractFactory
{
    class AudiTire : Tire
    {

    }
}
