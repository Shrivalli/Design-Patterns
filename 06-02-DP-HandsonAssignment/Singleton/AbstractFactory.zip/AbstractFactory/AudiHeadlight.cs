﻿namespace AbstractFactory
{
    class AudiHeadlight : Headlight
    {

    }
}
