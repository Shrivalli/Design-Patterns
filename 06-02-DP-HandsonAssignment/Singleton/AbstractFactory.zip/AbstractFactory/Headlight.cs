﻿namespace AbstractFactory
{
    abstract class Headlight
    {

    }
}
